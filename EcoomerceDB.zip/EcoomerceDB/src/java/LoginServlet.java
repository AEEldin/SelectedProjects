
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        String username = request.getParameter("username");
        String userpass = request.getParameter("password");
        //String date = new Date().toString();
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<body>");
        try {

            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection c = DriverManager
                    .getConnection("jdbc:oracle:thin:@//oracle1.cise.ufl.edu:1521/orcl", "shubhi", "Anjali144");

            Statement st = c.createStatement();

            ResultSet rs = st.executeQuery("select * from registration where username='"
                    + username + "'");
            String username1 = new String();
            String password1 = new String();

            while (rs.next()) {
                username1 = rs.getString(1);

                password1 = rs.getString(5);
            }

            if (userpass.equals(password1) && username.equals(username1)) {

				//HttpSession session = request.getSession(true);
                //session.setAttribute("S3CRET", "S3CRET");
                //session.setAttribute("full", full);
                response.sendRedirect("home.jsp");
                return;
            } else {

                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

        } catch (SQLException e) {
            out.println("SQL Exception " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        out.println("</body>");
        out.println("</html>");

    }

}
