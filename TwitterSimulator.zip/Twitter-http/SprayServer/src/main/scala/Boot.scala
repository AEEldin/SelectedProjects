import akka.actor.{ ActorSystem, Props }
import akka.io.IO
import spray.can.Http
import scala.concurrent.duration._
import akka.pattern.ask
import akka.util.Timeout
import akka.actor._
import spray.can.Http
import spray.can.server.Stats
import spray.util._
import spray.http._
import HttpMethods._
import MediaTypes._
import spray.can.Http.RegisterChunkHandler
import java.util.Random
import java.util.HashMap
import java.util.ArrayList

case class StartServer(statisticsActor: ActorRef, numberofUsers: Int, tweetsperUser: Int, numberOfActors: Int, numberOfTweetPerHome: Int)

class DemoService extends Actor with ActorLogging {
  implicit val timeout: Timeout = 1.second // for the actor 'asks'
  import context.dispatcher // ExecutionContext for the futures and scheduler
  var tweetsPerHome: Int = _
  var maxStoredTweets: Int = _
  var maxNumberUsers: Int = _
  var registeredUsers: Int = _ //counter as userID
  var numberOfWorkerActors: Int = _
  var randomGenerator = new Random()
  var workers: Array[ActorRef] = _
  var nextWorker = 0
  var numberOfWorkers = 0

  var userTweets: HashMap[Int, ArrayList[String]] = new HashMap
  var userFollowers: HashMap[Int, ArrayList[Int]] = new HashMap
  var users: ArrayList[Int] = new ArrayList
  var statisticsColletor: ActorRef = _

  def receive = {
    case StartServer(statisticsActor, numberofUsers, tweetsperUser, numberOfActors, numberOfTweetPerHome) =>
      println("Starting server...." + numberofUsers + " " + tweetsperUser)
      tweetsPerHome = numberOfTweetPerHome
      maxNumberUsers = numberofUsers
      maxStoredTweets = tweetsperUser
      registeredUsers = 0
      statisticsColletor = statisticsActor
      //create workers
      numberOfWorkers = numberOfActors

      //create users and settings
      var counter = 0
      while (counter < maxNumberUsers) {
        users.add(counter)
        var newlist = new ArrayList[String]
        userTweets.put(counter, newlist)

        //create followers
        var followers = new ArrayList[Int]
        var numberOfFollowers = 0
        if (users.size() < 1000) {
          numberOfFollowers = randomGenerator.nextInt(users.size())
        } else {
          numberOfFollowers = randomGenerator.nextInt(1000)
        }

        var index = 0;
        while (numberOfFollowers > 0) {
          index = randomGenerator.nextInt(users.size())
          var followerId = users.get(index);
          if ((!followers.contains(followerId)) && (followerId != counter)) {
            followers.add(followerId)
            numberOfFollowers = numberOfFollowers - 1;
          }
        }
        userFollowers.put(counter, followers)
        println("user with user id=" + counter + ", numberof followers=" + followers.size())
        counter = counter + 1
      }
    // when a new connection comes in we register ourselves as the connection handler
    case _: Http.Connected =>
      sender ! Http.Register(self)

    case HttpRequest(GET, Uri.Path("/"), _, _, _) =>
      sender ! index

    case HttpRequest(GET, Uri.Path(path), _, _, _) if path startsWith "/register" =>
      var userId = path.substring(path.indexOf("-") + 1).toInt
      var followers = userFollowers.get(userId)
      var indx = 0;
      var followersList = "";
      while (indx < followers.size) {
        followersList = followersList + followers.get(indx) + ","
        indx = indx + 1
      }
      sender ! HttpResponse(entity = "" + userId + "-" + followersList)

    case HttpRequest(GET, Uri.Path(path), _, _, _) if path startsWith "/getProfileTweet" =>
      var userId = path.substring(path.indexOf("-") + 1).toInt
      var userHomeTweets = userTweets.get(userId)
      var indx = 0;
      var tweetsList = "";

      var followersList = userFollowers.get(userId)
      var followersNumber = followersList.size()
      if (followersNumber > 0) {
        var averageTweetsPerFollower = (tweetsPerHome / followersNumber).toInt
        var pointer = 0
        while (pointer < followersList.size()) {
          var followerId = followersList.get(pointer)
          //homeTweets.add("Tweets from follower: " + followerId)
          var followerTweets = userTweets.get(followerId)
          if (followerTweets.size() <= averageTweetsPerFollower) {
            var counter = 0
            while (counter < followerTweets.size()) {
              tweetsList = tweetsList + followerId + ":" + followerTweets.get(counter) + "\n"
              counter = counter + 1
            }
          } else {
            var counter = averageTweetsPerFollower - 1
            while (counter > 0) {
              tweetsList = tweetsList + followerId + ":" + followerTweets.get(counter) + "\n"
              counter = counter - 1
            }
          } //end of internal else

          pointer = pointer + 1
        }
      }
      sender ! HttpResponse(entity = "" + userId + "-" + tweetsList)

    case HttpRequest(POST, Uri.Path(path), _, _, _) if path startsWith "/tweet" =>
      println(path.substring(path.indexOf("-") + 1))
      var userInfo = path.substring(path.indexOf("-") + 1).split(",")
      var userId = userInfo(0).toInt
      var tweetMessage = userInfo(1)
      storeUserTweet(userId, tweetMessage)
      sender ! HttpResponse(entity = "OK")

    case HttpRequest(GET, Uri.Path("/stream"), _, _, _) =>
      val peer = sender // since the Props creator is executed asyncly we need to save the sender ref
      context actorOf Props(new Streamer(peer, 25))

    case HttpRequest(GET, Uri.Path("/server-stats"), _, _, _) =>
      val client = sender
      context.actorFor("/user/IO-HTTP/listener-0") ? Http.GetStats onSuccess {
        case x: Stats => client ! statsPresentation(x)
      }

    case HttpRequest(GET, Uri.Path("/crash"), _, _, _) =>
      sender ! HttpResponse(entity = "About to throw an exception in the request handling actor, " +
        "which triggers an actor restart")
      sys.error("BOOM!")

    case HttpRequest(GET, Uri.Path(path), _, _, _) if path startsWith "/timeout" =>
      log.info("Dropping request, triggering a timeout")

    case HttpRequest(GET, Uri.Path("/stop"), _, _, _) =>
      sender ! HttpResponse(entity = "Shutting down in 1 second ...")
      sender ! Http.Close
      context.system.scheduler.scheduleOnce(1.second) { context.system.shutdown() }

    case _: HttpRequest => sender ! HttpResponse(status = 404, entity = "Unknown resource!")

    case Timedout(HttpRequest(_, Uri.Path("/timeout/timeout"), _, _, _)) =>
      log.info("Dropping Timeout message")

    case Timedout(HttpRequest(method, uri, _, _, _)) =>
      sender ! HttpResponse(
        status = 500,
        entity = "The " + method + " request to '" + uri + "' has timed out...")
  }

  ////////////// helpers //////////////

  lazy val index = HttpResponse(
    entity = HttpEntity(`text/html`,
      <html>
        <body>
          <h1>Say hello to <i>spray-can</i>!</h1>
          <p>Defined resources:</p>
          <ul>
            <li><a href="/ping">/ping</a></li>
            <li><a href="/stream">/stream</a></li>
            <li><a href="/server-stats">/server-stats</a></li>
            <li><a href="/crash">/crash</a></li>
            <li><a href="/timeout">/timeout</a></li>
            <li><a href="/timeout/timeout">/timeout/timeout</a></li>
            <li><a href="/stop">/stop</a></li>
          </ul>
        </body>
      </html>.toString()))

  def statsPresentation(s: Stats) = HttpResponse(
    entity = HttpEntity(`text/html`,
      <html>
        <body>
          <h1>HttpServer Stats</h1>
          <table>
            <tr><td>uptime:</td><td>{ s.uptime.formatHMS }</td></tr>
            <tr><td>totalRequests:</td><td>{ s.totalRequests }</td></tr>
            <tr><td>openRequests:</td><td>{ s.openRequests }</td></tr>
            <tr><td>maxOpenRequests:</td><td>{ s.maxOpenRequests }</td></tr>
            <tr><td>totalConnections:</td><td>{ s.totalConnections }</td></tr>
            <tr><td>openConnections:</td><td>{ s.openConnections }</td></tr>
            <tr><td>maxOpenConnections:</td><td>{ s.maxOpenConnections }</td></tr>
            <tr><td>requestTimeouts:</td><td>{ s.requestTimeouts }</td></tr>
          </table>
        </body>
      </html>.toString()))

  def storeUserTweet(userId: Int, tweetMessage: String) {
    var userList = userTweets.get(userId)
    userList.add(tweetMessage)
    if (userList.size() == maxStoredTweets) //exceeds the maximum number of stored tweets per user, then remove first
      userList.remove(0)
  }
  class Streamer(client: ActorRef, count: Int) extends Actor with ActorLogging {
    log.debug("Starting streaming response ...")

    // we use the successful sending of a chunk as trigger for scheduling the next chunk
    client ! ChunkedResponseStart(HttpResponse(entity = " " * 2048)).withAck(Ok(count))

    def receive = {
      case Ok(0) =>
        log.info("Finalizing response stream ...")
        client ! MessageChunk("\nStopped...")
        client ! ChunkedMessageEnd
        context.stop(self)

      case Ok(remaining) =>
        log.info("Sending response chunk ...")
        context.system.scheduler.scheduleOnce(100 millis span) {
          client ! MessageChunk(DateTime.now.toIsoDateTimeString + ", ").withAck(Ok(remaining - 1))
        }

      case x: Http.ConnectionClosed =>
        log.info("Canceling response stream due to {} ...", x)
        context.stop(self)
    }

    // simple case class whose instances we use as send confirmation message for streaming chunks
    case class Ok(remaining: Int)
  }
}

object Boot {
  def main(args: Array[String]) {
    implicit val system = ActorSystem()
    val handler = system.actorOf(Props[DemoService], name = "handler")
    handler ! StartServer(null, args(0).toInt, 10, 4, 30)
    IO(Http) ! Http.Bind(handler, interface = "localhost", port = 8080)
  }
}