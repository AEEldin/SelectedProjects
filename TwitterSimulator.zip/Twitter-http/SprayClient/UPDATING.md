on_spray-can_1.1 is the main branch. The order of merges:

 * update on_spray-can_1.1
 * merge on_spray-can_1.1 into on_spray-can_1.2 and 1.0 and adapt to new version
 * merge on_spray-can_1.1 into on_jetty_1.1 and adapt to new version
 * finally merge on_jetty_1.1 into on_jetty_1.2 and 1.0 and adapt to new version
