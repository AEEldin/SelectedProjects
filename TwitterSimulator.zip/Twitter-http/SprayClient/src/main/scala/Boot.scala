package com.example

import akka.actor.{ ActorSystem, Props }
import akka.io.IO
import spray.can.Http
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration._
import scala.util.{ Failure, Success }
import scala.concurrent.Future
import scala.concurrent.duration._
import akka.io.IO
import akka.util.Timeout
import akka.pattern.ask
import akka.actor._
import spray.can.Http
import spray.http._
import HttpMethods._
import java.util.ArrayList
import java.util.Random

trait ConnectionLevelApiDemo {
  private implicit val timeout: Timeout = 5.seconds
  private var ConnPortnumber: Int = 1000
  private var ClientReq: String = ""
  private var connectionConunber: Int = 0

  def demoConnectionLevelApi(host: String, reqport: Int, clreq: String, method: HttpMethod)(implicit system: ActorSystem): Future[ProductVersion] = {
    ConnPortnumber = reqport
    ClientReq = clreq
    val actor = system.actorOf(Props(new MyRequestActor(host)), name = host + connectionConunber)
    connectionConunber = connectionConunber + 1
    val future = actor ? HttpRequest(method, ClientReq)
    future.mapTo[ProductVersion]
  }

  // Actor that manages the lifecycle of a single HTTP connection for a single request
  class MyRequestActor(host: String) extends Actor with ActorLogging {
    import context.system
    def receive: Receive = {
      case request: HttpRequest =>
        println("request is sent")
        IO(Http) ! Http.Connect(host, port = ConnPortnumber)
        context.become(connecting(sender, request))
    }

    def connecting(commander: ActorRef, request: HttpRequest): Receive = {
      case _: Http.Connected =>
        println("now we are connected")
        sender ! request
        if (request.method == GET) {
          if (request.uri.path.toString.contains("register")) {
            context.become(waitingForResponse(commander))
          } else {
            context.become(displayTweets(commander))
          }

        } else {
          context.become(waitingForPostResponse(commander))
        }
      case Http.CommandFailed(Http.Connect(address, _, _, _, _)) =>
        println("Could not connect")
        commander ! Status.Failure(new RuntimeException("Connection error"))
        context.stop(self)
    }

    def waitingForResponse(commander: ActorRef): Receive = {
      case response @ HttpResponse(status, entity, _, _) =>
        var regsiterationInfo = entity.asString.split("-")
        var userId = regsiterationInfo(0).toInt
        if (regsiterationInfo.size > 1)
          print("User Id = " + userId + ",followers = " + regsiterationInfo(1))

        sender ! Http.Close
        context.become(waitingForClose(commander, response))
    }

    def displayTweets(commander: ActorRef): Receive = {
      case response @ HttpResponse(status, entity, _, _) =>
        var info = entity.asString.split("-")
        println("user " + info(0) + " tweets...")
        if (info.size > 1)
          println(info(1))
        sender ! Http.Close
        context.become(waitingForClose(commander, response))
      case ev @ (Http.SendFailed(_) | Timedout(_)) =>
        println("timeout error")
        commander ! Status.Failure(new RuntimeException("Request error"))
        context.stop(self)
    }

    def waitingForPostResponse(commander: ActorRef): Receive = {
      case response @ HttpResponse(status, entity, _, _) =>
        println("reached post ---" + entity)
        sender ! Http.Close
        context.become(waitingForClose(commander, response))
    }

    def waitingForClose(commander: ActorRef, response: HttpResponse): Receive = {
      case ev: Http.ConnectionClosed =>
        println("Connection closed")
        commander ! Status.Success(response.header[HttpHeaders.Server].get.products.head)
        context.stop(self)
      case Http.CommandFailed(Http.Close) =>
        println("Could not close connection")
        commander ! Status.Failure(new RuntimeException("Connection close error"))
        context.stop(self)
    }
  }
}

case class httpStart(id: Int, delay: Int, percentageOfTweet: Int, percentageOfGetHome: Int)

class ClientActor extends Actor with App with ConnectionLevelApiDemo {

  def receive = {
    case httpStart(id, delay, percentageOfTweet, percentageOfGetHome) =>

      implicit val system = ActorSystem("simple-example")
      import system.dispatcher
      var userId = id
      var delayPerRequest = delay
      var percentageOfTweets = percentageOfTweet
      var percentageOfGetHomeTweets = percentageOfGetHome
      var userActionsLength = 100
      var PostId = 0
      var userActions = new Array[Int](userActionsLength)
      // action 1 is get home, 2 tweet
      var getHomeActionNumber = 1
      var tweetActionNumber = 2
      //fill user action array with user destribution
      for (i <- 0 until userActionsLength) {
        userActions(i) = -1
      }

      var randomGenerator = new Random()
      var randomIndex = randomGenerator.nextInt(userActionsLength)
      while (percentageOfTweets > 0) {
        if (userActions(randomIndex) == -1) { //this cell is idle, has no existing actions
          userActions(randomIndex) = tweetActionNumber
          percentageOfTweets = percentageOfTweets - 1
        }
        randomIndex = randomGenerator.nextInt(userActionsLength)
      }
      randomIndex = 0
      while (percentageOfGetHomeTweets > 0) {
        if (userActions(randomIndex) == -1) { //this cell is idle, has no existing actions
          userActions(randomIndex) = getHomeActionNumber
          percentageOfGetHomeTweets = percentageOfGetHomeTweets - 1
        }
        randomIndex = randomIndex + 1
      }
      //register @ server
      var host = "localhost"
      var pnum = 8080
      var creq = "/register-" + userId
      val result = for { result1 <- demoConnectionLevelApi(host, pnum, creq, GET) } yield Set(result1)
      result onComplete {
        case Success(res) => println("Connected")
        case Failure(error) => println("Connection failed")
      }
      result onComplete { _ => println("Registered..") }

      Thread.sleep(1000)
      //send user actions to server
      while (true) {
        var action = 0
        for (i <- 0 until userActionsLength) {
          action = userActions(i)
          if (action == tweetActionNumber) {
            //tweet
            creq = "/tweet-" + userId + ",hiiii" + PostId
            var result2 = for { resultx <- demoConnectionLevelApi(host, pnum, creq, POST) } yield Set(resultx)
            result2 onComplete {
              case Success(res2) => println("Connected")
              case Failure(error2) => println("Connection failed")
            }
            result2 onComplete { _ => println("tweet sent..") }
          } else if (action == getHomeActionNumber) {
            //get home message
            println("sending get home request..")
            creq = "/getProfileTweet-" + userId
            var result4 = for { resultz <- demoConnectionLevelApi(host, pnum, creq, GET) } yield Set(resultz)
            result4 onComplete {
              case Success(res4) => println("Connected")
              case Failure(error4) => println("Connection failed")
            }
            result4 onComplete { _ => println("got home tweets..") }
          }
          Thread.sleep(delayPerRequest)
          PostId = (PostId + 1) % Int.MaxValue
        }
      }
  }

}

object Boot {
  def main(args: Array[String]) {
    implicit val system = ActorSystem("ActorSystem")
    var numberOfUsers = args(0).toInt
    var delayPerRequest = args(1).toInt
    var percentageOfTweets = args(2).toInt
    var percentageOfGetHome = args(3).toInt

    var tusers = new Array[ActorRef](numberOfUsers);
    var counter = 0
    while (counter < numberOfUsers) {
      tusers(counter) = system.actorOf(Props[ClientActor])

      tusers(counter) ! httpStart(counter, delayPerRequest, percentageOfTweets, percentageOfGetHome)
      counter = counter + 1
      Thread.sleep(1000)
    }

  }
}
